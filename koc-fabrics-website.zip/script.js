
const $$ = (s, r=document) => r.querySelector(s);
const $$$ = (s, r=document) => Array.from(r.querySelectorAll(s));

// Year in footer
(() => { const y = new Date().getFullYear(); const el = $$("#year"); if (el) el.textContent = y; })();

// Cart state
const CART_KEY = "koc_cart";
function getCart(){ try { return JSON.parse(localStorage.getItem(CART_KEY) || "[]"); } catch { return []; } }
function setCart(items){ localStorage.setItem(CART_KEY, JSON.stringify(items)); updateCartCount(); }
function addToCart(item){
  const cart = getCart();
  const existing = cart.find(i => i.id === item.id);
  if (existing) existing.qty += item.qty || 1;
  else cart.push({...item, qty: item.qty || 1});
  setCart(cart);
  openCart();
}
function removeFromCart(id){
  const cart = getCart().filter(i => i.id !== id);
  setCart(cart);
  renderCart();
}
function updateQty(id, qty){
  const cart = getCart().map(i => i.id === id ? {...i, qty: Math.max(1, qty)} : i);
  setCart(cart);
  renderCart();
}
function cartSubtotal(){
  return getCart().reduce((s,i)=> s + (i.price*i.qty), 0);
}
function money(n){ return "K" + n.toFixed(2); }
function updateCartCount(){
  const count = getCart().reduce((s,i)=> s + i.qty, 0);
  const el = $$("#cartCount"); if (el) el.textContent = count;
}
updateCartCount();

// Cart drawer
const drawer = $$("#cartDrawer"), scrim = $$("#cartScrim");
const openBtn = $$("#openCart"), closeBtn = $$("#closeCart");
function openCart(){ if (drawer){ drawer.classList.add("open"); drawer.setAttribute("aria-hidden","false"); renderCart(); } }
function closeCart(){ if (drawer){ drawer.classList.remove("open"); drawer.setAttribute("aria-hidden","true"); } }
openBtn && openBtn.addEventListener("click", openCart);
closeBtn && closeBtn.addEventListener("click", closeCart);
scrim && scrim.addEventListener("click", closeCart);

// Render cart
function renderCart(){
  const list = $$("#cartItems"); if (!list) return;
  const cart = getCart();
  if (cart.length === 0){
    list.innerHTML = '<p>Your cart is empty.</p>';
    $$("#cartSubtotal").textContent = money(0);
    return;
  }
  list.innerHTML = cart.map(i => `
    <div class="cart-item">
      <img src="assets/logo.png" alt="${i.name}">
      <div>
        <div><strong>${i.name}</strong></div>
        <div class="meta">${i.category} • ${i.color}</div>
        <div class="meta">${money(i.price)} ${i.unit}</div>
      </div>
      <div>
        <input type="number" min="1" value="${i.qty}" style="width:64px" aria-label="Quantity" />
        <button style="display:block;margin-top:6px" aria-label="Remove" data-remove="${i.id}">Remove</button>
      </div>
    </div>
  `).join("");
  // Attach events
  $$$(".cart-item input").forEach((inp, idx) => {
    const id = cart[idx].id;
    inp.addEventListener("change", e => updateQty(id, parseInt(e.target.value || "1", 10)));
  });
  $$$("[data-remove]").forEach(btn => btn.addEventListener("click", e => removeFromCart(e.target.getAttribute("data-remove"))));
  $$("#cartSubtotal").textContent = money(cartSubtotal());
}
$$("#checkoutBtn") && $$("#checkoutBtn").addEventListener("click", () => {
  const cart = getCart();
  if (cart.length === 0) return;
  // Basic checkout: generate an email draft
  const lines = cart.map(i => `• ${i.name} x${i.qty} — ${money(i.price*i.qty)}`);
  const body = encodeURIComponent(`Hello KOC Fabrics,%0D%0A%0D%0AI would like to place the following order:%0D%0A${lines.join("%0D%0A")}%0D%0A%0D%0ASubtotal: ${money(cartSubtotal())}%0D%0A%0D%0AName:%0D%0APhone:%0D%0ADelivery Address:`);
  window.location.href = `mailto:orders@kocfabrics.com?subject=KOC Fabrics Order&body=${body}`;
});

// Load products & featured
async function loadJSON(url){ const res = await fetch(url); return res.json(); }

(async () => {
  const pg = document.body.contains($$("#productGrid"));
  const featured = document.body.contains($$("#featuredGrid"));
  const blogList = document.body.contains($$("#blogList"));
  let data = null;

  if (pg || featured){
    data = await loadJSON("products.json");
  }
  if (featured){
    const items = data.filter(p => p.featured);
    $$("#featuredGrid").innerHTML = items.map(cardHTML).join("");
    hookCardButtons();
  }
  if (pg){
    const grid = $$("#productGrid");
    function render(list){ grid.innerHTML = list.map(cardHTML).join(""); hookCardButtons(); }
    function applyFilters(){
      const q = ($$("#searchInput").value || "").toLowerCase();
      const cat = $$("#categoryFilter").value;
      let list = data.filter(p => (!cat || p.category===cat) && (p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q) || p.color.toLowerCase().includes(q)));
      render(list);
    }
    render(data);
    $$("#searchInput").addEventListener("input", applyFilters);
    $$("#categoryFilter").addEventListener("change", applyFilters);
  }
  if (blogList){
    const posts = await loadJSON("blog.json");
    blogList.innerHTML = posts.map(p => `
      <article class="card">
        <div class="meta">${p.date}</div>
        <h3>${p.title}</h3>
        <p>${p.excerpt}</p>
        <a class="btn ghost" href="#">Read</a>
      </article>
    `).join("");
  }
})();

function cardHTML(p){
  return `
    <article class="card product-card">
      <div class="product-thumb"></div>
      <h3>${p.name}</h3>
      <div class="meta">${p.category} • ${p.color}</div>
      <div class="actions">
        <span class="price">${money(p.price)}</span>
        <button class="btn" data-add='${JSON.stringify(p).replace(/'/g,"&apos;")}'>Add to cart</button>
      </div>
      <div class="meta">${p.unit}</div>
    </article>
  `;
}
function hookCardButtons(){
  $$$("[data-add]").forEach(btn => btn.addEventListener("click", e => {
    const p = JSON.parse(e.currentTarget.getAttribute("data-add").replace(/&apos;/g, "'"));
    addToCart(p);
  }));
}

// Contact form -> mailto
const contact = $$("#contactForm");
if (contact){
  contact.addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(contact);
    const subject = encodeURIComponent("Website enquiry");
    const body = encodeURIComponent(`Name: ${fd.get("name")}\nEmail: ${fd.get("email")}\n\n${fd.get("message")}`);
    window.location.href = `mailto:hello@kocfabrics.com?subject=${subject}&body=${body}`;
  });
}
